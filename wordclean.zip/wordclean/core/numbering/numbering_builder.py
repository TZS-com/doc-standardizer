"""
Word多级编号生成
"""


from lxml import etree




NS = {

    "w":

    "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

}




def create_numbering(
        level,
        num_id
):
    """
    创建编号结构
    """


    abstract_num = etree.Element(

        "{%s}abstractNum"

        %

        NS["w"]

    )


    abstract_num.set(

        "{%s}abstractNumId"

        %

        NS["w"],

        str(num_id)

    )


    for i in range(level):


        lvl = etree.SubElement(

            abstract_num,

            "{%s}lvl"

            %

            NS["w"]

        )


        lvl.set(

            "{%s}ilvl"

            %

            NS["w"],

            str(i)

        )


        start = etree.SubElement(

            lvl,

            "{%s}start"

            %

            NS["w"]

        )


        start.set(

            "{%s}val"

            %

            NS["w"],

            "1"

        )


        fmt = etree.SubElement(

            lvl,

            "{%s}numFmt"

            %

            NS["w"]

        )


        fmt.set(

            "{%s}val"

            %

            NS["w"],

            "decimal"

        )


    return abstract_num