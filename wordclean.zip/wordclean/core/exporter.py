"""
Word导出模块

负责:
1. XML目录重新打包
2. 生成新的docx文件
"""


import os

import zipfile



from utils.exception import WordProcessException




def package_docx(
        source_dir,
        output_file
):
    """
    将解压后的Word目录重新打包

    参数:
        source_dir:
            docx解压目录

        output_file:
            输出docx路径
    """


    try:


        with zipfile.ZipFile(

                output_file,

                "w",

                zipfile.ZIP_DEFLATED

        ) as zip_file:



            for root, dirs, files in os.walk(source_dir):


                for file in files:


                    full_path = os.path.join(

                        root,

                        file

                    )


                    relative_path = os.path.relpath(

                        full_path,

                        source_dir

                    )


                    zip_file.write(

                        full_path,

                        relative_path

                    )



    except Exception as e:


        raise WordProcessException(

            f"Word打包失败:{e}"

        )