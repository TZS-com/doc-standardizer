"""
Word XML读取模块

负责:
1. 解压docx
2. 获取document.xml
3. 获取styles.xml
4. XML解析
"""


import zipfile

import os


from lxml import etree




WORD_NAMESPACE = {

    "w":
    "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

}





def extract_docx(docx_path, output_dir):
    """
    解压docx
    """


    if not os.path.exists(output_dir):

        os.makedirs(output_dir)



    with zipfile.ZipFile(
        docx_path,
        "r"
    ) as zip_file:


        zip_file.extractall(
            output_dir
        )




def load_xml(xml_path):
    """
    加载XML文件
    """


    tree = etree.parse(
        xml_path
    )


    return tree




def get_document_xml(docx_dir):
    """
    获取document.xml
    """


    path = os.path.join(

        docx_dir,

        "word",

        "document.xml"

    )


    return load_xml(path)




def get_styles_xml(docx_dir):


    path = os.path.join(

        docx_dir,

        "word",

        "styles.xml"

    )


    return load_xml(path)




def get_numbering_xml(docx_dir):


    path = os.path.join(

        docx_dir,

        "word",

        "numbering.xml"

    )


    return load_xml(path)