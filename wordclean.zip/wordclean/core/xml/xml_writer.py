"""
XML写入模块
"""


from lxml import etree




def save_xml(tree,path):


    tree.write(

        path,

        encoding="utf-8",

        xml_declaration=True,

        pretty_print=True

    )