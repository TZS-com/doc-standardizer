"""
文件工具
"""


import os

from config.settings import (
    SUPPORTED_EXTENSIONS
)



def get_docx_files(directory):


    files=[]


    for root,dirs,names in os.walk(directory):

        for name in names:


            ext=os.path.splitext(
                name
            )[1].lower()


            if ext in SUPPORTED_EXTENSIONS:


                files.append(

                    os.path.join(
                        root,
                        name
                    )

                )


    return files



def create_dir(path):


    if not os.path.exists(path):

        os.makedirs(path)