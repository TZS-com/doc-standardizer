"""
自定义异常
"""


class WordProcessException(Exception):

    """
    Word处理异常
    """

    pass