"""
日志模块
"""


import os

from loguru import logger

from config.settings import LOG_DIR



os.makedirs(
    LOG_DIR,
    exist_ok=True
)



logger.add(

    os.path.join(
        LOG_DIR,
        "process.log"
    ),

    rotation="10 MB",

    encoding="utf-8",

    level="INFO"

)



def get_logger():

    return logger