"""
Word文档标准化工具入口

职责：

1. 扫描输入目录
2. 批量处理docx
3. 调用核心处理流程
4. 输出日志


业务逻辑不要写在这里


"""


import os



from tqdm import tqdm



from config.settings import (

    INPUT_DIR,

    OUTPUT_DIR

)



from utils.file_utils import (

    get_docx_files,

    create_dir

)



from utils.logger import (

    get_logger

)



from core.document_processor import (

    DocumentProcessor

)





logger = get_logger()






def build_output_path(
        input_file
):
    """
    根据输入文件生成输出路径

    例如:

    input/a.docx

    输出:

    output/a.docx

    """



    filename = os.path.basename(

        input_file

    )



    return os.path.join(

        OUTPUT_DIR,

        filename

    )








def process_single_file(
        input_file
):
    """
    单个Word处理

    """



    output_file = build_output_path(

        input_file

    )



    logger.info(

        f"开始处理:{input_file}"

    )



    processor = DocumentProcessor(

        input_file,

        output_file

    )



    processor.process()



    logger.info(

        f"处理完成:{output_file}"

    )









def main():



    logger.info(

        "=" * 50

    )


    logger.info(

        "Word标准化程序启动"

    )



    logger.info(

        "=" * 50

    )



    # 创建输出目录


    create_dir(

        OUTPUT_DIR

    )



    # 获取Word文件


    files = get_docx_files(

        INPUT_DIR

    )



    if not files:


        logger.warning(

            "没有发现docx文件"

        )


        return




    logger.info(

        f"发现Word数量:{len(files)}"

    )





    success_count = 0


    failed_count = 0





    for file in tqdm(

            files,

            desc="处理中"

    ):



        try:



            process_single_file(

                file

            )



            success_count += 1





        except Exception as e:



            failed_count += 1



            logger.exception(

                f"处理失败:{file},原因:{e}"

            )







    logger.info(

        "=" * 50

    )


    logger.info(

        "处理统计"

    )


    logger.info(

        f"成功:{success_count}"

    )


    logger.info(

        f"失败:{failed_count}"

    )


    logger.info(

        "=" * 50

    )







if __name__ == "__main__":


    main()