"""
表格识别规则
"""


TABLE_TYPES={


    "equipment":

    {

        "keywords":

        [

            "设备",

            "型号",

            "数量"

        ],

        "template":

        "equipment_table"

    },



    "parameter":

    {

        "keywords":

        [

            "参数",

            "要求",

            "指标"

        ],

        "template":

        "parameter_table"

    },



    "approval":

    {

        "keywords":

        [

            "申请人",

            "审核人",

            "日期"

        ],

        "template":

        "approval_table"

    }


}