"""
系统全局配置
"""


import os


# 项目根目录

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


# 输入目录

INPUT_DIR = os.path.join(
    BASE_DIR,
    "input"
)


# 输出目录

OUTPUT_DIR = os.path.join(
    BASE_DIR,
    "output"
)


# 模板目录

TEMPLATE_DIR = os.path.join(
    BASE_DIR,
    "template"
)


# 日志目录

LOG_DIR = os.path.join(
    BASE_DIR,
    "logs"
)


TEMP_DIR = os.path.join(
    BASE_DIR,
    "temp"
)


ENABLE_AI = False


# Word模板

STANDARD_TEMPLATE = os.path.join(
    TEMPLATE_DIR,
    "standard.docx"
)


# 是否启用AI

# 第一阶段关闭

ENABLE_AI = False



# 支持文件类型

SUPPORTED_EXTENSIONS = [
    ".docx"
]


# 默认编码

ENCODING = "utf-8"