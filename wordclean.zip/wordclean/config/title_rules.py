"""
标题识别规则
"""


# 一级标题

LEVEL_ONE = {

    "pattern":
    r"^[一二三四五六七八九十百]+、",

    "level":1

}



# 二级标题

LEVEL_TWO = {

    "pattern":
    r"^\d+[、.．]",

    "level":2

}



# 三级标题

LEVEL_THREE = {

    "pattern":
    r"^\d+\.\d+",

    "level":3

}



# 四级标题

LEVEL_FOUR = {

    "pattern":
    r"^（\d+）",

    "level":4

}



TITLE_RULES=[

    LEVEL_ONE,

    LEVEL_THREE,

    LEVEL_TWO,

    LEVEL_FOUR

]