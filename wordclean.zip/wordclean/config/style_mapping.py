"""
Word样式映射配置
"""


# 标题映射

TITLE_STYLE_MAP = {

    1:
    "Heading 1",

    2:
    "Heading 2",

    3:
    "Heading 3",

    4:
    "Heading 4"

}



# 正文

BODY_STYLE = "Normal"



# 表格正文

TABLE_BODY_STYLE = "Table Body"



# 表格标题

TABLE_HEADER_STYLE = "Table Header"